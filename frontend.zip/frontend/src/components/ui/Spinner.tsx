import { LoaderCircle } from "lucide-react";
import { cn } from "@/lib/cn";

export function Spinner({
  className
}: {
  className?: string;
}) {
  return (
    <LoaderCircle
      className={cn("size-5 animate-spin text-blue-700", className)}
    />
  );
}
